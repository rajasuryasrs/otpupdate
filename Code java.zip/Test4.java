package in.sis.ps;

import in.sis.ps.logger.LoggerManager;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import javax.servlet.ServletContext;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import java.sql.ResultSet;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.QueryParam;
import org.json.JSONObject;


@Path("/testing")
@Produces("application/json")
public class Test4 {
    public Test4() {
    }
    private ServletContext servletContext;
    private final static String FAILURE_MSG = "Failure";
    private final static String SUCCESS_MSG = "Success";
    private final BigDecimal errorRespCode = new BigDecimal(1);
    private final BigDecimal successRespCode = new BigDecimal(0);

    @GET
        @Path("/testpath")
        @Produces("application/json")
        public Response testpath (@QueryParam("employee_code") String employee_code)       
        {  
            Connection connection = null;
            PreparedStatement name = null;
            Statement stmt = null;
            ResultSet rs = null;
            String jsonError = null;
        
            String employeecode = null;
            String employeename = null;
            String recordid = null;
            String companycode = null;
            String branchcode = null;
            String branchname = null;
            String mobilepersonal = null;
            String mobileoffice = null;
        
            JSONObject joOutput = new JSONObject();
            JSONObject joOutput1 = new JSONObject();
            try 
            {
                System.out.println("begin");
                if (employee_code == null) {
                    jsonError = "Y";
                    joOutput.put("ResponseCode", errorRespCode);
                    joOutput.put("ResponseType", FAILURE_MSG);
                    joOutput.put("ResponseMessage", "Input Parameters not adequate");
                } else {
                    JSONObject outjson = null;
//                  connection = getConnection("psDS");
                    connection = getConnection();
                    if (connection != null) 
                    {
                        if (employee_code != null) {
                            String query = "Select RECORD_ID,COMPANY_CODE,EMPLOYEE_CODE,EMPLOYEE_NAME,BRANCH_CODE,BRANCH_NAME,MOBILE_PERSONAL,MOBILE_OFFICE From ps_tb_employee_defn Where EMPLOYEE_CODE = ? ";
                            name = connection.prepareStatement(query);
                            name.setString(1, employee_code);
                            ResultSet rstset = name.executeQuery();
                            int h = 0;
                            while (rstset.next()) 
                            {
                                recordid = rstset.getString("RECORD_ID");  
                                companycode = rstset.getString("COMPANY_CODE");
                                employeecode = rstset.getString("EMPLOYEE_CODE");  
                                employeename = rstset.getString("EMPLOYEE_NAME");
                                branchcode = rstset.getString("BRANCH_CODE");  
                                branchname = rstset.getString("BRANCH_NAME"); 
                                mobilepersonal = rstset.getString("MOBILE_PERSONAL");  
                                mobileoffice = rstset.getString("MOBILE_OFFICE"); 
                                
                                joOutput.put("record_id", recordid); 
                                joOutput.put("company_code", companycode);
                                joOutput.put("employee_name", employeename); 
                                joOutput.put("employee_code", employeecode);
                                joOutput.put("branch_code", branchcode); 
                                joOutput.put("branch_name", branchname);
                                joOutput.put("mobile_personal", mobilepersonal); 
                                joOutput.put("mobile_office", mobileoffice);
                               
                                h++;
                            }
                            if (joOutput.length() > 0) {
                                joOutput1.put("ResponseCode", successRespCode);
                                joOutput1.put("ResponseType", SUCCESS_MSG);
                                joOutput1.put("ResponseMessage", joOutput);
                            } else {
                                joOutput.put("ResponseCode", errorRespCode);
                                joOutput.put("ResponseType", FAILURE_MSG);
                                joOutput.put("ResponseMessage", "No Data Found..!");
                            }
                        }
                    } 
                    else {
                        joOutput.put("ResponseCode", errorRespCode);
                        joOutput.put("ResponseType", FAILURE_MSG);
                        joOutput.put("ResponseMessage", "Connection not available");
                    }
                }
            } 
            catch (Exception e) {}
            //return Response.ok(joOutput.toString()).header("Access-Control-Allow-Origin", "*").build();
            return Response.ok(joOutput.toString()).header("Access-Control-Allow-Origin", "*").build();
        }
    
        private Connection getConnection() throws Exception 
        {
            Connection connection = null;
            try 
            {
                javax.naming.Context initialContext = new javax.naming.InitialContext();
                javax.sql.DataSource dataSource = (javax.sql.DataSource)initialContext.lookup("psDS");
                connection = dataSource.getConnection();
            } catch (Exception e) { }
            return connection;
        }
}