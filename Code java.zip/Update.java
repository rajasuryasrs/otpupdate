package in.sis.ps;

import in.sis.ps.logger.LoggerManager;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import javax.servlet.ServletContext;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.QueryParam;
import org.json.JSONObject;
import java.sql.CallableStatement;
import java.sql.Types;

@Path("/updateing")
@Produces("application/json")
public class Update 
{
    LoggerManager logger = new LoggerManager();
    public Update() {}
    private ServletContext servletContext;
    private final static String FAILURE_MSG = "Failure";
    private final static String SUCCESS_MSG = "Success";
    private final BigDecimal errorRespCode = new BigDecimal(1);
    private final BigDecimal successRespCode = new BigDecimal(0);

    @POST
    @Path("/updatepath")
    @Produces("application/json")
    public Response updateEmployeeDetails 
    (
        @FormParam("employee_record_id") String employee_record_id,
        @FormParam("company_code") String company_code, 
        @FormParam("employee_code") String employee_code,                                   
        @FormParam("existing_personal_no") String existing_personal_no,                                
        @FormParam("existing_official_no") String existing_official_no,                                  
        @FormParam("revised_personal_no") String revised_personal_no,          
        @FormParam("revised_official_no") String revised_official_no
    )       
    {  
       Connection connection = null;
       CallableStatement statement = null;
        JSONObject joOutput = new JSONObject();
        try 
        {
            connection = getConnection();
                if (connection != null) 
                {
                    statement = connection.prepareCall("{call PS_PK_IUD_BRANCH_DTLS.PS_PR_UPD_EMPLOYEE_MOBILE(?,?,?,?,?,?,?,?,?,?)}");
                    statement.setBigDecimal(1, new BigDecimal(employee_record_id));
                    statement.setString(2, company_code);
                    statement.setString(3, employee_code);
                    statement.setString(4, existing_personal_no);
                    statement.setString(5, existing_official_no);
                    statement.setString(6, revised_personal_no);
                    statement.setString(7, revised_official_no);
                    statement.registerOutParameter(8, Types.VARCHAR);
                    statement.registerOutParameter(9, Types.VARCHAR);
                    statement.registerOutParameter(10, Types.VARCHAR);
                    statement.execute();
                    String errCode = statement.getString(8);
                    String errType = statement.getString(9);
                    String errMessage = statement.getString(10);
                    if (errCode != null && errType != null && errMessage != null) 
                    {  
                         joOutput.put("status", "2");
                         joOutput.put("message", errMessage);
                         //return Response.ok(joOutput.toString()).build();  
                         return Response.ok(joOutput.toString()).header("Access-Control-Allow-Origin", "*").build();
                    } 
                    else
                    {
                        connection.commit();
                        joOutput.put("status", "1");
                        joOutput.put("message", "Success");
                        //return Response.ok(joOutput.toString()).build();  
                        return Response.ok(joOutput.toString()).header("Access-Control-Allow-Origin", "*").build();
                    }
                }
            }
            catch (Exception e)
            {
                LoggerManager.raiseToLog(LoggerManager.ERROR, LoggerManager.methodName(), e.getMessage(), null,servletContext);
            }
            finally 
            {
                try 
                {
                    if (statement != null) {
                    statement.close();
                    }
                    if (connection != null) {
                    connection.close();
                    connection = null;
                    }
                } 
                catch (SQLException e) 
                {
                    LoggerManager.raiseToLog(LoggerManager.ERROR, LoggerManager.methodName(), e.getMessage(), null,servletContext);
                }
            }
            //return Response.ok(joOutput.toString()).build();   
            return Response.ok(joOutput.toString()).header("Access-Control-Allow-Origin", "*").build();
    }      
            
    private Connection getConnection() throws Exception 
    {
        Connection connection = null;
        try 
        {
            javax.naming.Context initialContext = new javax.naming.InitialContext();
            javax.sql.DataSource dataSource = (javax.sql.DataSource)initialContext.lookup("psDS");
            connection = dataSource.getConnection();
        } 
        catch (Exception e) {}
        return connection;
    }
}